})(typeof exports !== 'undefined' ? exports : XLSX);
var XLS = XLSX;
